ActiveProbing intermittently pings Microsoft's Servers to check for a network connection. For Privacy, this is disabled by default. 
Which may cause the network icon to display a disconnected icon while you still have a stable connection.

To fix this, run the "Enable ActiveProbing.reg" in this directory and reboot.