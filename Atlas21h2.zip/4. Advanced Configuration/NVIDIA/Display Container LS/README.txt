Disabling 'NVIDIA Display Container LS'
-----------------------------------------
The 'NVIDIA Display Container LS' service uses quite a decent amount of CPU usage in the background doing nothing from my
experience, so it is best to disable the service from running constantly in the background when you do not even use it.
For convenience, you can add a context menu to the desktop to enable/disable the service.

Warning: Disabling the 'NVIDIA Display Container LS' service will make it so you can not use NVIDIA Control Panel!