If you don't know what these are, either research or DO NOT RUN THEM.
 You use these at your own risk. Some of these scripts are highly experimental and still in development.