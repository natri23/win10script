#Requires -Version 5
Invoke-RestMethod https://get.scoop.sh | Invoke-Expression
